const ApiError = require('../utils/apiError');

class ErrorMiddleware {
  handleErrors(err, req, res, next) {
    const statusCode = err.statusCode || 500;
    const message = err.message || 'Internal Server Error';

    res.status(statusCode).json({
      success: false,
      message,
      stack: process.env.NODE_ENV === 'development' ? err.stack : undefined,
    });
  }
}

module.exports = new ErrorMiddleware();
